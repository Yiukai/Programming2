package Assignment_two;

public interface PayRoll {
    double computePayRoll(double payRoll);
}
