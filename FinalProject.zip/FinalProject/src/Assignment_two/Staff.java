package Assignment_two;

public class Staff extends Person implements PayRoll{
    int id;
    String name;
    int age;
    String gender;
    String duty;
    int workload;
    int department_id;
    double payRoll;
      
    Staff(){}
    Staff(int id, String name, int age, String gender,String duty, int workload,int department_id){
        this.id = id;
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.duty = duty;
        this.workload = workload;
        this.department_id = department_id;
    }
    @Override
    void setGender(String gender){
        this.gender = gender;
    }
    @Override
    String getGender(){
        return this.gender;
    }
    @Override
    void setAge(int age){
        this.age = age;
    }
    @Override
    int getAge(){
        return this.age;
    }
    @Override
    public void setName(String name){
        this.name = name;
    }
    @Override
    public String getName(){
        return this.name;
    }
    @Override
    public void setId(int id){
        this.id = id;
    }
    @Override
    public int getId(){
        return this.id;
    }
    void setDepartmentId(int department_id){
        this.department_id = department_id;
    }
    int getDepartmentId(){
        return this.department_id;
    }
    void setPayRoll(double payRoll){
        this.payRoll = payRoll;
    }
    double getPayRoll(){
        return this.payRoll;
    }
    void setDuty(String duty){
        this.duty = duty;
    }
    String getDuty(){
        return this.duty;
    }
    void setWorkload(int workload){
        this.workload = workload;
    }
    int getWorkload(){
        return this.workload;
    }   
    @Override
    public double computePayRoll(double payRoll) {
        payRoll = workload*32*2*0.85;
        return payRoll;
    }
    @Override
    public String toString(){
        return "ID: "+getId()+"\n"+
               "Name: "+getName()+"\n"+
               "Age: "+getAge()+"\n"+
               "Gender: "+getGender()+"\n"+
               "Payroll: "+computePayRoll(this.payRoll)+"\n"+
               "Duty: "+getDuty()+"\n"+
               "Workload: "+getWorkload()+"\n"+
               "Department id:"+getDepartmentId()+"\n";
    }
}
